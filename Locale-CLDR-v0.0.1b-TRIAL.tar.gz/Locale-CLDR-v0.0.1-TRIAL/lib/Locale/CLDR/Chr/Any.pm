package Locale::CLDR::Chr::Any;
# This file auto generated
#	on Sun 23 Mar  7:25:21 pm GMT

use v5.18;
use mro 'c3';

use Moose;

extends('Locale::CLDR::Chr');

no Moose;
__PACKAGE__->meta->make_immutable;
