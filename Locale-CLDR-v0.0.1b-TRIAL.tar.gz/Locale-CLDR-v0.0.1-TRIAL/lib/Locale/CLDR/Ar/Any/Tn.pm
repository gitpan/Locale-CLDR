package Locale::CLDR::Ar::Any::Tn;
# This file auto generated from Data\common\main\ar_TN.xml
#	on Sun 30 Mar 11:40:20 pm GMT
# XML file generated 2014-01-08 23:53:23 -0600 (Wed, 08 Jan 2014)

use v5.18;
use mro 'c3';
use utf8;

use Moose;

extends('Locale::CLDR::Ar::Any');
