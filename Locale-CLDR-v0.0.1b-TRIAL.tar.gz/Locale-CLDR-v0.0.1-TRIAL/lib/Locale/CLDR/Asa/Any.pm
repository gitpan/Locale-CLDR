package Locale::CLDR::Asa::Any;
# This file auto generated
#	on Sun 23 Mar  7:15:21 pm GMT

use v5.18;
use mro 'c3';

use Moose;

extends('Locale::CLDR::Asa');

no Moose;
__PACKAGE__->meta->make_immutable;
