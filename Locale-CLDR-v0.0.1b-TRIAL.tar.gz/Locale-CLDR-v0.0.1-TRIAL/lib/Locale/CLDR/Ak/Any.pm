package Locale::CLDR::Ak::Any;
# This file auto generated
#	on Sun 23 Mar  6:08:29 pm GMT

use v5.18;
use mro 'c3';

use Moose;

extends('Locale::CLDR::Ak');

no Moose;
__PACKAGE__->meta->make_immutable;
