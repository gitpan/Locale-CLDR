package Locale::CLDR::Es::Any::Co;
# This file auto generated from Data\common\main\es_CO.xml
#	on Mon 31 Mar 12:14:07 am GMT
# XML file generated 2013-08-14 01:51:50 -0500 (Wed, 14 Aug 2013)

use v5.18;
use mro 'c3';
use utf8;

use Moose;

extends('Locale::CLDR::Es::Any');
