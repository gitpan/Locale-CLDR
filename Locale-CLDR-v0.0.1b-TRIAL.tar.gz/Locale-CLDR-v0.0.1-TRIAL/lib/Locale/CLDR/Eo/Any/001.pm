package Locale::CLDR::Eo::Any::001;
# This file auto generated from Data\common\main\eo_001.xml
#	on Mon 31 Mar 12:12:20 am GMT
# XML file generated 2013-08-24 16:19:30 -0500 (Sat, 24 Aug 2013)

use v5.18;
use mro 'c3';
use utf8;

use Moose;

extends('Locale::CLDR::Eo::Any');
