package Locale::CLDR::Eo::Any;
# This file auto generated
#	on Sun 23 Mar  7:31:52 pm GMT

use v5.18;
use mro 'c3';

use Moose;

extends('Locale::CLDR::Eo');

no Moose;
__PACKAGE__->meta->make_immutable;
