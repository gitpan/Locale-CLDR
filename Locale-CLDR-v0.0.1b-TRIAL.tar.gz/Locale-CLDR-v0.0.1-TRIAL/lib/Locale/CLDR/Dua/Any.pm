package Locale::CLDR::Dua::Any;
# This file auto generated
#	on Sun 23 Mar  7:27:40 pm GMT

use v5.18;
use mro 'c3';

use Moose;

extends('Locale::CLDR::Dua');

no Moose;
__PACKAGE__->meta->make_immutable;
