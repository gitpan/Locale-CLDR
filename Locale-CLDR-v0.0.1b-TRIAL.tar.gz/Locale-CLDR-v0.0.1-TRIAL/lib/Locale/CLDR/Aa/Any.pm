package Locale::CLDR::Aa::Any;
# This file auto generated
#	on Sun 23 Mar  6:07:59 pm GMT

use v5.18;
use mro 'c3';

use Moose;

extends('Locale::CLDR::Aa');

no Moose;
__PACKAGE__->meta->make_immutable;
