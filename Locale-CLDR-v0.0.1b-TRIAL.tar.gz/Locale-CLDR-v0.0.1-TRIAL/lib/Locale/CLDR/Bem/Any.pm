package Locale::CLDR::Bem::Any;
# This file auto generated
#	on Sun 23 Mar  7:16:38 pm GMT

use v5.18;
use mro 'c3';

use Moose;

extends('Locale::CLDR::Bem');

no Moose;
__PACKAGE__->meta->make_immutable;
