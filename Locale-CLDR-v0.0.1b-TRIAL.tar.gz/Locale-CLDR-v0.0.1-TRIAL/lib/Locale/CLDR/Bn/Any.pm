package Locale::CLDR::Bn::Any;
# This file auto generated
#	on Sun 23 Mar  7:20:15 pm GMT

use v5.18;
use mro 'c3';

use Moose;

extends('Locale::CLDR::Bn');

no Moose;
__PACKAGE__->meta->make_immutable;
