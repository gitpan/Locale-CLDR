package Locale::CLDR::Ee::Any;
# This file auto generated
#	on Sun 23 Mar  7:29:30 pm GMT

use v5.18;
use mro 'c3';

use Moose;

extends('Locale::CLDR::Ee');

no Moose;
__PACKAGE__->meta->make_immutable;
