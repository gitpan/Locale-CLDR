package Locale::CLDR::Agq::Any;
# This file auto generated
#	on Sun 23 Mar  6:08:28 pm GMT

use v5.18;
use mro 'c3';

use Moose;

extends('Locale::CLDR::Agq');

no Moose;
__PACKAGE__->meta->make_immutable;
