package Locale::CLDR::En::Any::Sg;
# This file auto generated from Data\common\main\en_SG.xml
#	on Mon 31 Mar 12:12:18 am GMT
# XML file generated 2013-12-04 17:53:48 -0600 (Wed, 04 Dec 2013)

use v5.18;
use mro 'c3';
use utf8;

use Moose;

extends('Locale::CLDR::En::Any');
