package Locale::CLDR::En::Any::Rw;
# This file auto generated from Data\common\main\en_RW.xml
#	on Mon 31 Mar 12:12:18 am GMT
# XML file generated 2013-08-22 18:59:54 -0500 (Thu, 22 Aug 2013)

use v5.18;
use mro 'c3';
use utf8;

use Moose;

extends('Locale::CLDR::En::Any');
