package Locale::CLDR::En::Any::Sb;
# This file auto generated from Data\common\main\en_SB.xml
#	on Mon 31 Mar 12:12:18 am GMT
# XML file generated 2013-08-07 23:47:50 -0500 (Wed, 07 Aug 2013)

use v5.18;
use mro 'c3';
use utf8;

use Moose;

extends('Locale::CLDR::En::Any');
