package Locale::CLDR::Ca::Any::It;
# This file auto generated from Data\common\main\ca_IT.xml
#	on Sun 30 Mar 11:58:45 pm GMT
# XML file generated 2013-08-18 23:26:52 -0500 (Sun, 18 Aug 2013)

use v5.18;
use mro 'c3';
use utf8;

use Moose;

extends('Locale::CLDR::Ca::Any');
