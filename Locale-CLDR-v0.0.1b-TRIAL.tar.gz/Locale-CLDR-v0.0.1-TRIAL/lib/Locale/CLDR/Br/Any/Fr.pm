package Locale::CLDR::Br::Any::Fr;
# This file auto generated from Data\common\main\br_FR.xml
#	on Sun 30 Mar 11:49:19 pm GMT
# XML file generated 2013-07-20 12:27:45 -0500 (Sat, 20 Jul 2013)

use v5.18;
use mro 'c3';
use utf8;

use Moose;

extends('Locale::CLDR::Br::Any');
