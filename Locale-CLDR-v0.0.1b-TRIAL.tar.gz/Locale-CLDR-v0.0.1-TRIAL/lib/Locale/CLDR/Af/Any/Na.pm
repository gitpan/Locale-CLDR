package Locale::CLDR::Af::Any::Na;
# This file auto generated from Data\common\main\af_NA.xml
#	on Sun 30 Mar 11:35:09 pm GMT
# XML file generated 2013-08-28 21:32:04 -0500 (Wed, 28 Aug 2013)

use v5.18;
use mro 'c3';
use utf8;

use Moose;

extends('Locale::CLDR::Af::Any');
