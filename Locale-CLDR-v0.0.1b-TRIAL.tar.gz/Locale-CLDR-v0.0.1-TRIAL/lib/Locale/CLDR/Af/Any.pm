package Locale::CLDR::Af::Any;
# This file auto generated
#	on Sun 23 Mar  6:08:27 pm GMT

use v5.18;
use mro 'c3';

use Moose;

extends('Locale::CLDR::Af');

no Moose;
__PACKAGE__->meta->make_immutable;
