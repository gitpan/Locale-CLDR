package Locale::CLDR::Ebu::Any;
# This file auto generated
#	on Sun 23 Mar  7:28:04 pm GMT

use v5.18;
use mro 'c3';

use Moose;

extends('Locale::CLDR::Ebu');

no Moose;
__PACKAGE__->meta->make_immutable;
