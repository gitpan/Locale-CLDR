package Locale::CLDR::Be::Any;
# This file auto generated
#	on Sun 23 Mar  7:16:37 pm GMT

use v5.18;
use mro 'c3';

use Moose;

extends('Locale::CLDR::Be');

no Moose;
__PACKAGE__->meta->make_immutable;
