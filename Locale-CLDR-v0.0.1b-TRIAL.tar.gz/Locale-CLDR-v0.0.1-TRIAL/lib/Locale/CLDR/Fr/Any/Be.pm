package Locale::CLDR::Fr::Any::Be;
# This file auto generated from Data\common\main\fr_BE.xml
#	on Mon 31 Mar 12:25:17 am GMT
# XML file generated 2013-07-20 12:27:45 -0500 (Sat, 20 Jul 2013)

use v5.18;
use mro 'c3';
use utf8;

use Moose;

extends('Locale::CLDR::Fr::Any');
