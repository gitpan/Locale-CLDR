package Locale::CLDR::Ak::Any::Gh;
# This file auto generated from Data\common\main\ak_GH.xml
#	on Sun 30 Mar 11:35:17 pm GMT
# XML file generated 2013-07-20 12:27:45 -0500 (Sat, 20 Jul 2013)

use v5.18;
use mro 'c3';
use utf8;

use Moose;

extends('Locale::CLDR::Ak::Any');
