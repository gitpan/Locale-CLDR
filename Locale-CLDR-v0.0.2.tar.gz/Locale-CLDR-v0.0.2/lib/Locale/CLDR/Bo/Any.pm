package Locale::CLDR::Bo::Any;
# This file auto generated
#	on Sun 23 Mar  7:20:16 pm GMT

use v5.18;
use mro 'c3';

use Moose;

extends('Locale::CLDR::Bo');

no Moose;
__PACKAGE__->meta->make_immutable;
