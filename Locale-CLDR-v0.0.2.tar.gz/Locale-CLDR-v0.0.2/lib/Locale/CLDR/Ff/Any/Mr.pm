package Locale::CLDR::Ff::Any::Mr;
# This file auto generated from Data\common\main\ff_MR.xml
#	on Mon 31 Mar 12:20:51 am GMT
# XML file generated 2014-01-06 13:01:35 -0600 (Mon, 06 Jan 2014)

use v5.18;
use mro 'c3';
use utf8;

use Moose;

extends('Locale::CLDR::Ff::Any');
