package Locale::CLDR::Ff::Any::Sn;
# This file auto generated from Data\common\main\ff_SN.xml
#	on Mon 31 Mar 12:20:51 am GMT
# XML file generated 2013-07-20 12:27:45 -0500 (Sat, 20 Jul 2013)

use v5.18;
use mro 'c3';
use utf8;

use Moose;

extends('Locale::CLDR::Ff::Any');
