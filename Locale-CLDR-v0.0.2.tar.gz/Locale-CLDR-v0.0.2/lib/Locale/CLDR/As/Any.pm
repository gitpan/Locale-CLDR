package Locale::CLDR::As::Any;
# This file auto generated
#	on Sun 23 Mar  7:15:20 pm GMT

use v5.18;
use mro 'c3';

use Moose;

extends('Locale::CLDR::As');

no Moose;
__PACKAGE__->meta->make_immutable;
