package Locale::CLDR::Zgh;
# This file auto generated from Data\common\main\zgh.xml
#	on Mon 31 Mar  2:25:21 am GMT
# XML file generated 2013-08-28 21:32:04 -0500 (Wed, 28 Aug 2013)

use v5.18;
use mro 'c3';
use utf8;

use Moose;

extends('Locale::CLDR::Root');
has 'display_name_language' => (
	is			=> 'ro',
	isa			=> 'CodeRef',
	init_arg	=> undef,
	default		=> sub { 
		 sub {
			 my %languages = (
				'ak' => 'ⵜⴰⴽⴰⵏⵜ',
 				'am' => 'ⵜⴰⵎⵀⴰⵔⵉⵜ',
 				'ar' => 'ⵜⴰⵄⵔⴰⴱⵜ',
 				'be' => 'ⵜⴰⴱⵉⵍⴰⵔⵓⵙⵜ',
 				'bg' => 'ⵜⴰⴱⵍⵖⴰⵔⵉⵜ',
 				'bn' => 'ⵜⴰⴱⵏⵖⴰⵍⵉⵜ',
 				'cs' => 'ⵜⴰⵜⵛⵉⴽⵉⵜ',
 				'de' => 'ⵜⴰⵍⵉⵎⴰⵏⵜ',
 				'el' => 'ⵜⴰⴳⵔⵉⴳⵉⵜ',
 				'en' => 'ⵜⴰⵏⴳⵍⵉⵣⵜ',
 				'es' => 'ⵜⴰⵙⴱⵏⵢⵓⵍⵉⵜ',
 				'fa' => 'ⵜⴰⴼⵓⵔⵙⵉⵜ',
 				'fr' => 'ⵜⴰⴼⵔⴰⵏⵙⵉⵙⵜ',
 				'ha' => 'ⵜⴰⵀⴰⵡⵙⴰⵜ',
 				'hi' => 'ⵜⴰⵀⵉⵏⴷⵉⵜ',
 				'hu' => 'ⵜⴰⵀⵏⵖⴰⵔⵉⵜ',
 				'id' => 'ⵜⴰⵏⴷⵓⵏⵉⵙⵉⵜ',
 				'ig' => 'ⵜⵉⴳⴱⵓⵜ',
 				'it' => 'ⵜⴰⵟⴰⵍⵢⴰⵏⵜ',
 				'ja' => 'ⵜⴰⵊⴰⴱⴱⵓⵏⵉⵜ',
 				'jv' => 'ⵜⴰⵊⴰⴱⴰⵏⵉⵜ',
 				'km' => 'ⵜⴰⵅⵎⵉⵔⵜ',
 				'ko' => 'ⵜⴰⴽⵓⵔⵉⵜ',
 				'ms' => 'ⵜⴰⵎⴰⵍⴰⵡⵉⵜ',
 				'my' => 'ⵜⴰⴱⵉⵔⵎⴰⵏⵉⵜ',
 				'ne' => 'ⵜⴰⵏⵉⴱⴰⵍⵉⵜ',
 				'nl' => 'ⵜⴰⵀⵓⵍⴰⵏⴷⵉⵜ',
 				'pa' => 'ⵜⴰⴱⵏⵊⴰⴱⵉⵜ',
 				'pl' => 'ⵜⴰⴱⵓⵍⵓⵏⵉⵜ',
 				'pt' => 'ⵜⴰⴱⵕⵟⵇⵉⵣⵜ',
 				'ro' => 'ⵜⴰⵔⵓⵎⴰⵏⵉⵜ',
 				'ru' => 'ⵜⴰⵔⵓⵙⵉⵜ',
 				'rw' => 'ⵜⴰⵔⵓⵡⴰⵏⴷⵉⵜ',
 				'so' => 'ⵜⴰⵙⵓⵎⴰⵍⵉⵜ',
 				'sv' => 'ⵜⴰⵙⵡⵉⴷⵉⵜ',
 				'ta' => 'ⵜⴰⵜⴰⵎⵉⵍⵜ',
 				'th' => 'ⵜⴰⵜⴰⵢⵍⴰⵏⴷⵉⵜ',
 				'tr' => 'ⵜⴰⵜⵓⵔⴽⵉⵜ',
 				'uk' => 'ⵜⵓⴽⵔⴰⵏⵉⵜ',
 				'ur' => 'ⵜⵓⵔⴷⵓⵜ',
 				'vi' => 'ⵜⴰⴱⵉⵜⵏⴰⵎⵉⵜ',
 				'yo' => 'ⵜⴰⵢⵔⵓⴱⴰⵜ',
 				'zgh' => 'ⵜⴰⵎⴰⵣⵉⵖⵜ',
 				'zh' => 'ⵜⴰⵛⵉⵏⵡⵉⵜ',
 				'zu' => 'ⵜⴰⵣⵓⵍⵓⵜ',

			);
			if (@_) {
				return $languages{$_[0]};
			}
			return \%languages;
		}
	},
);

has 'display_name_territory' => (
	is			=> 'ro',
	isa			=> 'HashRef[Str]',
	init_arg	=> undef,
	default		=> sub { 
		{
			'AD' => 'ⴰⵏⴷⵓⵔⴰ',
 			'AE' => 'ⵍⵉⵎⴰⵔⴰⵜ',
 			'AF' => 'ⴰⴼⵖⴰⵏⵉⵙⵜⴰⵏ',
 			'AG' => 'ⴰⵏⵜⵉⴳⴰ ⴷ ⴱⵔⴱⵓⴷⴰ',
 			'AI' => 'ⴰⵏⴳⵉⵍⴰ',
 			'AL' => 'ⴰⵍⴱⴰⵏⵢⴰ',
 			'AM' => 'ⴰⵔⵎⵉⵏⵢⴰ',
 			'AO' => 'ⴰⵏⴳⵓⵍⴰ',
 			'AR' => 'ⴰⵔⵊⴰⵏⵜⵉⵏ',
 			'AS' => 'ⵙⴰⵎⵡⴰ ⵜⴰⵎⵉⵔⵉⴽⴰⵏⵉⵜ',
 			'AT' => 'ⵏⵏⵎⵙⴰ',
 			'AU' => 'ⵓⵙⵜⵔⴰⵍⵢⴰ',
 			'AW' => 'ⴰⵔⵓⴱⴰ',
 			'AZ' => 'ⴰⴷⵔⴰⴱⵉⵊⴰⵏ',
 			'BA' => 'ⴱⵓⵙⵏⴰ ⴷ ⵀⵉⵔⵙⵉⴽ',
 			'BB' => 'ⴱⴰⵔⴱⴰⴷ',
 			'BD' => 'ⴱⴰⵏⴳⵍⴰⴷⵉⵛ',
 			'BE' => 'ⴱⵍⵊⵉⴽⴰ',
 			'BF' => 'ⴱⵓⵔⴽⵉⵏⴰ ⴼⴰⵙⵓ',
 			'BG' => 'ⴱⵍⵖⴰⵔⵢⴰ',
 			'BH' => 'ⴱⵃⵔⴰⵢⵏ',
 			'BI' => 'ⴱⵓⵔⵓⵏⴷⵉ',
 			'BJ' => 'ⴱⵉⵏⵉⵏ',
 			'BM' => 'ⴱⵔⵎⵓⴷⴰ',
 			'BN' => 'ⴱⵔⵓⵏⵉ',
 			'BO' => 'ⴱⵓⵍⵉⴱⵢⴰ',
 			'BR' => 'ⴱⵔⴰⵣⵉⵍ',
 			'BS' => 'ⴱⴰⵀⴰⵎⴰⵙ',
 			'BT' => 'ⴱⵀⵓⵜⴰⵏ',
 			'BW' => 'ⴱⵓⵜⵙⵡⴰⵏⴰ',
 			'BY' => 'ⴱⵉⵍⴰⵔⵓⵙⵢⴰ',
 			'BZ' => 'ⴱⵉⵍⵉⵣ',
 			'CA' => 'ⴽⴰⵏⴰⴷⴰ',
 			'CD' => 'ⵜⴰⴳⴷⵓⴷⴰⵏⵜ ⵜⴰⴷⵉⵎⵓⵇⵔⴰⵜⵉⵜ ⵏ ⴽⵓⵏⴳⵓ',
 			'CF' => 'ⵜⴰⴳⴷⵓⴷⴰⵏⵜ ⵜⴰⵏⴰⵎⵎⴰⵙⵜ ⵏ ⵉⴼⵔⵉⵇⵢⴰ',
 			'CG' => 'ⴽⵓⵏⴳⵓ',
 			'CH' => 'ⵙⵡⵉⵙⵔⴰ',
 			'CI' => 'ⴽⵓⵜ ⴷⵉⴼⵡⴰⵔ',
 			'CK' => 'ⵜⵉⴳⵣⵉⵔⵉⵏ ⵏ ⴽⵓⴽ',
 			'CL' => 'ⵛⵛⵉⵍⵉ',
 			'CM' => 'ⴽⴰⵎⵉⵔⵓⵏ',
 			'CN' => 'ⵛⵛⵉⵏⵡⴰ',
 			'CO' => 'ⴽⵓⵍⵓⵎⴱⵢⴰ',
 			'CR' => 'ⴽⵓⵙⵜⴰ ⵔⵉⴽⴰ',
 			'CU' => 'ⴽⵓⴱⴰ',
 			'CV' => 'ⵜⵉⴳⵣⵉⵔⵉⵏ ⵏ ⴽⴰⴱⴱⵉⵔⴷⵉ',
 			'CY' => 'ⵇⵓⴱⵔⵓⵙ',
 			'CZ' => 'ⵜⴰⴳⴷⵓⴷⴰⵏⵜ ⵜⴰⵜⵛⵉⴽⵉⵜ',
 			'DE' => 'ⴰⵍⵎⴰⵏⵢⴰ',
 			'DJ' => 'ⴷⵊⵉⴱⵓⵜⵉ',
 			'DK' => 'ⴷⴰⵏⵎⴰⵔⴽ',
 			'DM' => 'ⴷⵓⵎⵉⵏⵉⴽ',
 			'DO' => 'ⵜⴰⴳⴷⵓⴷⴰⵏⵜ ⵜⴰⴷⵓⵎⵉⵏⵉⴽⵜ',
 			'DZ' => 'ⴷⵣⴰⵢⵔ',
 			'EC' => 'ⵉⴽⵡⴰⴷⵓⵔ',
 			'EE' => 'ⵉⵙⵜⵓⵏⵢⴰ',
 			'EG' => 'ⵎⵉⵚⵕ',
 			'ER' => 'ⵉⵔⵉⵜⵉⵔⵢⴰ',
 			'ES' => 'ⵙⴱⴰⵏⵢⴰ',
 			'ET' => 'ⵉⵜⵢⵓⴱⵢⴰ',
 			'FI' => 'ⴼⵉⵍⵍⴰⵏⴷⴰ',
 			'FJ' => 'ⴼⵉⴷⵊⵉ',
 			'FK' => 'ⵜⵉⴳⵣⵉⵔⵉⵏ ⵏ ⵎⴰⵍⴰⵡⵉ',
 			'FM' => 'ⵎⵉⴽⵔⵓⵏⵉⵣⵢⴰ',
 			'FR' => 'ⴼⵔⴰⵏⵙⴰ',
 			'GA' => 'ⴳⴰⴱⵓⵏ',
 			'GB' => 'ⵜⴰⴳⵍⴷⵉⵜ ⵉⵎⵓⵏⵏ',
 			'GD' => 'ⵖⵔⵏⴰⵟⴰ',
 			'GE' => 'ⵊⵓⵔⵊⵢⴰ',
 			'GF' => 'ⴳⵡⵉⵢⴰⵏ ⵜⴰⴼⵔⴰⵏⵙⵉⵙⵜ',
 			'GH' => 'ⵖⴰⵏⴰ',
 			'GI' => 'ⴰⴷⵔⴰⵔ ⵏ ⵟⴰⵕⵉⵇ',
 			'GL' => 'ⴳⵔⵉⵍⴰⵏⴷ',
 			'GM' => 'ⴳⴰⵎⴱⵢⴰ',
 			'GN' => 'ⵖⵉⵏⵢⴰ',
 			'GP' => 'ⴳⵡⴰⴷⴰⵍⵓⴱ',
 			'GQ' => 'ⵖⵉⵏⵢⴰ ⵏ ⵉⴽⵡⴰⴷⵓⵔ',
 			'GR' => 'ⵍⵢⵓⵏⴰⵏ',
 			'GT' => 'ⴳⵡⴰⵜⵉⵎⴰⵍⴰ',
 			'GU' => 'ⴳⵡⴰⵎ',
 			'GW' => 'ⵖⵉⵏⵢⴰ ⴱⵉⵙⴰⵡ',
 			'GY' => 'ⴳⵡⵉⵢⴰⵏⴰ',
 			'HN' => 'ⵀⵓⵏⴷⵓⵔⴰⵙ',
 			'HR' => 'ⴽⵔⵡⴰⵜⵢⴰ',
 			'HT' => 'ⵀⴰⵢⵜⵉ',
 			'HU' => 'ⵀⵏⵖⴰⵔⵢⴰ',
 			'ID' => 'ⴰⵏⴷⵓⵏⵉⵙⵢⴰ',
 			'IE' => 'ⵉⵔⵍⴰⵏⴷⴰ',
 			'IL' => 'ⵉⵙⵔⴰⵢⵉⵍ',
 			'IN' => 'ⵍⵀⵉⵏⴷ',
 			'IO' => 'ⵜⴰⵎⵏⴰⴹⵜ ⵜⴰⵏⴳⵍⵉⵣⵉⵜ ⵏ ⵓⴳⴰⵔⵓ ⴰⵀⵉⵏⴷⵉ',
 			'IQ' => 'ⵍⵄⵉⵔⴰⵇ',
 			'IR' => 'ⵉⵔⴰⵏ',
 			'IS' => 'ⵉⵙⵍⴰⵏⴷ',
 			'IT' => 'ⵉⵟⴰⵍⵢⴰ',
 			'JM' => 'ⵊⴰⵎⴰⵢⴽⴰ',
 			'JO' => 'ⵍⵓⵔⴷⵓⵏ',
 			'JP' => 'ⵍⵢⴰⴱⴰⵏ',
 			'KE' => 'ⴽⵉⵏⵢⴰ',
 			'KG' => 'ⴽⵉⵔⵖⵉⵣⵉⵙⵜⴰⵏ',
 			'KH' => 'ⴽⴰⵎⴱⵓⴷⵢⴰ',
 			'KI' => 'ⴽⵉⵔⵉⴱⴰⵜⵉ',
 			'KM' => 'ⵇⵓⵎⵓⵔ',
 			'KN' => 'ⵙⴰⵏⴽⵔⵉⵙ ⴷ ⵏⵉⴼⵉⵙ',
 			'KP' => 'ⴽⵓⵔⵢⴰ ⵏ ⵉⵥⵥⵍⵎⴹ',
 			'KR' => 'ⴽⵓⵔⵢⴰ ⵏ ⵉⴼⴼⵓⵙ',
 			'KW' => 'ⵍⴽⵡⵉⵜ',
 			'KY' => 'ⵜⵉⴳⵣⵉⵔⵉⵏ ⵏ ⴽⴰⵢⵎⴰⵏ',
 			'KZ' => 'ⴽⴰⵣⴰⵅⵙⵜⴰⵏ',
 			'LA' => 'ⵍⴰⵡⵙ',
 			'LB' => 'ⵍⵓⴱⵏⴰⵏ',
 			'LC' => 'ⵙⴰⵏⵜⵍⵓⵙⵉ',
 			'LI' => 'ⵍⵉⴽⵉⵏⵛⵜⴰⵢⵏ',
 			'LK' => 'ⵙⵔⵉⵍⴰⵏⴽⴰ',
 			'LR' => 'ⵍⵉⴱⵉⵔⵢⴰ',
 			'LS' => 'ⵍⵉⵚⵓⵟⵓ',
 			'LT' => 'ⵍⵉⵜⵡⴰⵏⵢⴰ',
 			'LU' => 'ⵍⵓⴽⵙⴰⵏⴱⵓⵔⴳ',
 			'LV' => 'ⵍⴰⵜⴼⵢⴰ',
 			'LY' => 'ⵍⵉⴱⵢⴰ',
 			'MA' => 'ⵍⵎⵖⵔⵉⴱ',
 			'MC' => 'ⵎⵓⵏⴰⴽⵓ',
 			'MD' => 'ⵎⵓⵍⴷⵓⴼⵢⴰ',
 			'ME' => 'ⵎⵓⵏⵜⵉⵏⵉⴳⵔⵓ',
 			'MG' => 'ⵎⴰⴷⴰⵖⴰⵛⵇⴰⵔ',
 			'MH' => 'ⵜⵉⴳⵣⵉⵔⵉⵏ ⵏ ⵎⴰⵔⵛⴰⵍ',
 			'MK' => 'ⵎⴰⵙⵉⴷⵓⵏⵢⴰ',
 			'ML' => 'ⵎⴰⵍⵉ',
 			'MM' => 'ⵎⵢⴰⵏⵎⴰⵔ',
 			'MN' => 'ⵎⵏⵖⵓⵍⵢⴰ',
 			'MP' => 'ⵜⵉⴳⵣⵉⵔⵉⵏ ⵏ ⵎⴰⵔⵢⴰⵏ ⵏ ⵉⵥⵥⵍⵎⴹ',
 			'MQ' => 'ⵎⴰⵔⵜⵉⵏⵉⴽ',
 			'MR' => 'ⵎⵓⵕⵉⵟⴰⵏⵢⴰ',
 			'MS' => 'ⵎⵓⵏⵙⵉⵔⴰⵜ',
 			'MT' => 'ⵎⴰⵍⵟⴰ',
 			'MU' => 'ⵎⵓⵔⵉⵙ',
 			'MV' => 'ⵎⴰⵍⴷⵉⴼ',
 			'MW' => 'ⵎⴰⵍⴰⵡⵉ',
 			'MX' => 'ⵎⵉⴽⵙⵉⴽ',
 			'MY' => 'ⵎⴰⵍⵉⵣⵢⴰ',
 			'MZ' => 'ⵎⵓⵣⵏⴱⵉⵇ',
 			'NA' => 'ⵏⴰⵎⵉⴱⵢⴰ',
 			'NC' => 'ⴽⴰⵍⵉⴷⵓⵏⵢⴰ ⵜⴰⵎⴰⵢⵏⵓⵜ',
 			'NE' => 'ⵏⵏⵉⵊⵉⵔ',
 			'NF' => 'ⵜⵉⴳⵣⵉⵔⵉⵏ ⵏ ⵏⵓⵔⴼⵓⵍⴽ',
 			'NG' => 'ⵏⵉⵊⵉⵔⵢⴰ',
 			'NI' => 'ⵏⵉⴽⴰⵔⴰⴳⵡⴰ',
 			'NL' => 'ⵀⵓⵍⴰⵏⴷⴰ',
 			'NO' => 'ⵏⵏⵔⵡⵉⵊ',
 			'NP' => 'ⵏⵉⴱⴰⵍ',
 			'NR' => 'ⵏⴰⵡⵔⵓ',
 			'NU' => 'ⵏⵉⵡⵉ',
 			'NZ' => 'ⵏⵢⵓⵣⵉⵍⴰⵏⴷⴰ',
 			'OM' => 'ⵄⵓⵎⴰⵏ',
 			'PA' => 'ⴱⴰⵏⴰⵎⴰ',
 			'PE' => 'ⴱⵉⵔⵓ',
 			'PF' => 'ⴱⵓⵍⵉⵏⵉⵣⵢⴰ ⵜⴰⴼⵔⴰⵏⵙⵉⵙⵜ',
 			'PG' => 'ⴱⴰⴱⵡⴰ ⵖⵉⵏⵢⴰ ⵜⴰⵎⴰⵢⵏⵓⵜ',
 			'PH' => 'ⴼⵉⵍⵉⴱⴱⵉⵏ',
 			'PK' => 'ⴱⴰⴽⵉⵙⵜⴰⵏ',
 			'PL' => 'ⴱⵓⵍⵓⵏⵢⴰ',
 			'PM' => 'ⵙⴰⵏⴱⵢⵉⵔ ⴷ ⵎⵉⴽⵍⵓⵏ',
 			'PN' => 'ⴱⵉⵜⴽⴰⵢⵔⵏ',
 			'PR' => 'ⴱⵓⵔⵜⵓ ⵔⵉⴽⵓ',
 			'PS' => 'ⴰⴳⵎⵎⴰⴹ ⵏ ⵜⴰⴳⵓⵜ ⴷ ⵖⵣⵣⴰ',
 			'PT' => 'ⴱⵕⵟⵇⵉⵣ',
 			'PW' => 'ⴱⴰⵍⴰⵡ',
 			'PY' => 'ⴱⴰⵔⴰⴳⵡⴰⵢ',
 			'QA' => 'ⵇⴰⵜⴰⵔ',
 			'RE' => 'ⵔⵉⵢⵓⵏⵢⵓⵏ',
 			'RO' => 'ⵔⵓⵎⴰⵏⵢⴰ',
 			'RS' => 'ⵙⵉⵔⴱⵢⴰ',
 			'RU' => 'ⵔⵓⵙⵢⴰ',
 			'RW' => 'ⵔⵡⴰⵏⴷⴰ',
 			'SA' => 'ⵙⵙⴰⵄⵓⴷⵉⵢⴰ',
 			'SB' => 'ⵜⵉⴳⵣⵉⵔⵉⵏ ⵏ ⵙⴰⵍⵓⵎⴰⵏ',
 			'SC' => 'ⵙⵙⵉⵛⵉⵍ',
 			'SD' => 'ⵙⵙⵓⴷⴰⵏ',
 			'SE' => 'ⵙⵙⵡⵉⴷ',
 			'SG' => 'ⵙⵏⵖⴰⴼⵓⵔⴰ',
 			'SH' => 'ⵙⴰⵏⵜⵉⵍⵉⵏ',
 			'SI' => 'ⵙⵍⵓⴼⵉⵏⵢⴰ',
 			'SK' => 'ⵙⵍⵓⴼⴰⴽⵢⴰ',
 			'SL' => 'ⵙⵙⵉⵔⴰⵍⵢⵓⵏ',
 			'SM' => 'ⵙⴰⵏⵎⴰⵔⵉⵏⵓ',
 			'SN' => 'ⵙⵙⵉⵏⵉⴳⴰⵍ',
 			'SO' => 'ⵚⵚⵓⵎⴰⵍ',
 			'SR' => 'ⵙⵓⵔⵉⵏⴰⵎ',
 			'SS' => 'ⵙⵙⵓⴷⴰⵏ ⵏ ⵉⴼⴼⵓⵙ',
 			'ST' => 'ⵙⴰⵡⵟⵓⵎⵉ ⴷ ⴱⵔⴰⵏⵙⵉⴱ',
 			'SV' => 'ⵙⴰⵍⴼⴰⴷⵓⵔ',
 			'SY' => 'ⵙⵓⵔⵢⴰ',
 			'SZ' => 'ⵙⵡⴰⵣⵉⵍⴰⵏⴷⴰ',
 			'TC' => 'ⵜⵉⴳⵣⵉⵔⵉⵏ ⵏ ⵜⵓⵔⴽⵢⴰ ⴷ ⴽⴰⵢⴽ',
 			'TD' => 'ⵜⵛⴰⴷ',
 			'TG' => 'ⵟⵓⴳⵓ',
 			'TH' => 'ⵟⴰⵢⵍⴰⵏⴷ',
 			'TJ' => 'ⵜⴰⴷⵊⴰⴽⵉⵙⵜⴰⵏ',
 			'TK' => 'ⵟⵓⴽⵍⴰⵡ',
 			'TL' => 'ⵜⵉⵎⵓⵔ ⵏ ⵍⵇⴱⵍⵜ',
 			'TM' => 'ⵜⵓⵔⴽⵎⴰⵏⵙⵜⴰⵏ',
 			'TN' => 'ⵜⵓⵏⵙ',
 			'TO' => 'ⵟⵓⵏⴳⴰ',
 			'TR' => 'ⵜⵓⵔⴽⵢⴰ',
 			'TT' => 'ⵜⵔⵉⵏⵉⴷⴰⴷ ⴷ ⵟⵓⴱⴰⴳⵓ',
 			'TV' => 'ⵜⵓⴼⴰⵍⵓ',
 			'TW' => 'ⵟⴰⵢⵡⴰⵏ',
 			'TZ' => 'ⵟⴰⵏⵥⴰⵏⵢⴰ',
 			'UA' => 'ⵓⴽⵔⴰⵏⵢⴰ',
 			'UG' => 'ⵓⵖⴰⵏⴷⴰ',
 			'US' => 'ⵉⵡⵓⵏⴰⴽ ⵎⵓⵏⵏⵉⵏ ⵏ ⵎⵉⵔⵉⴽⴰⵏ',
 			'UY' => 'ⵓⵔⵓⴳⵡⴰⵢ',
 			'UZ' => 'ⵓⵣⴱⴰⴽⵉⵙⵜⴰⵏ',
 			'VA' => 'ⴰⵡⴰⵏⴽ ⵏ ⴼⴰⵜⵉⴽⴰⵏ',
 			'VC' => 'ⵙⴰⵏⴼⴰⵏⵙⴰⵏ ⴷ ⴳⵔⵉⵏⴰⴷⵉⵏ',
 			'VE' => 'ⴼⵉⵏⵣⵡⵉⵍⴰ',
 			'VG' => 'ⵜⵉⴳⵣⵉⵔⵉⵏ ⵜⵉⵎⴳⴰⴷ ⵏ ⵏⵏⴳⵍⵉⵣ',
 			'VI' => 'ⵜⵉⴳⵣⵉⵔⵉⵏ ⵜⵉⵎⴳⴰⴷ ⵏ ⵉⵡⵓⵏⴰⴽ ⵎⵓⵏⵏⵉⵏ',
 			'VN' => 'ⴼⵉⵜⵏⴰⵎ',
 			'VU' => 'ⴼⴰⵏⵡⴰⵟⵓ',
 			'WF' => 'ⵡⴰⵍⵉⵙ ⴷ ⴼⵓⵜⵓⵏⴰ',
 			'WS' => 'ⵙⴰⵎⵡⴰ',
 			'YE' => 'ⵢⴰⵎⴰⵏ',
 			'YT' => 'ⵎⴰⵢⵓⵟ',
 			'ZA' => 'ⴰⴼⵔⵉⵇⵢⴰ ⵏ ⵉⴼⴼⵓⵙ',
 			'ZM' => 'ⵣⴰⵎⴱⵢⴰ',
 			'ZW' => 'ⵣⵉⵎⴱⴰⴱⵡⵉ',

		}
	},
);

has 'display_name_key' => (
	is			=> 'ro',
	isa			=> 'HashRef[Str]',
	init_arg	=> undef,
	default		=> sub { 
		{
			'calendar' => 'ⴰⵙⵎⵍⵓⵙⵙⴰⵏ',
 			'collation' => 'ⴰⵏⵎⴰⵍⴰ ⵏ ⵓⵙⵜⴰⵢ',
 			'currency' => 'ⴰⴷⵔⵉⵎ',

		}
	},
);

has 'display_name_type' => (
	is			=> 'ro',
	isa			=> 'HashRef[HashRef[Str]]',
	init_arg	=> undef,
	default		=> sub {
		{
			'calendar' => {
 				'coptic' => q{ⴰⵙⵎⵍⵓⵙⵙⴰⵏ ⴰⵇⴱⵟⵉ},
 				'ethiopic' => q{ⴰⵙⵎⵍⵓⵙⵙⴰⵏ ⵏ ⵉⵜⵢⵓⴱⵢⴰ},
 				'gregorian' => q{ⴰⵙⵎⵍⵓⵙⵙⴰⵏ ⴰⴳⵔⵉⴳⵓⵔ},
 				'islamic' => q{ⴰⵙⵎⵍⵓⵙⵙⴰⵏ ⵏ ⵍⵉⵙⵍⴰⵎ},
 			},

		}
	},
);

has 'characters' => (
	is			=> 'ro',
	isa			=> 'HashRef',
	init_arg	=> undef,
	default		=> sub {
		no warnings 'experimental::regex_sets';
		return {
			index => ['ⴰ', 'ⴱ', 'ⴳ', 'ⴷ', 'ⴹ', 'ⴻ', 'ⴼ', 'ⴽ', 'ⵀ', 'ⵃ', 'ⵄ', 'ⵅ', 'ⵇ', 'ⵉ', 'ⵊ', 'ⵍ', 'ⵎ', 'ⵏ', 'ⵓ', 'ⵔ', 'ⵕ', 'ⵖ', 'ⵙ', 'ⵚ', 'ⵛ', 'ⵜ', 'ⵟ', 'ⵡ', 'ⵢ', 'ⵣ', 'ⵥ'],
			main => qr{(?^u:[ⴰ ⴱ ⴳ {ⴳⵯ} ⴷ ⴹ ⴻ ⴼ ⴽ {ⴽⵯ} ⵀ ⵃ ⵄ ⵅ ⵇ ⵉ ⵊ ⵍ ⵎ ⵏ ⵓ ⵔ ⵕ ⵖ ⵙ ⵚ ⵛ ⵜ ⵟ ⵡ ⵢ ⵣ ⵥ])},
		};
	},
);

has 'quote_start' => (
	is			=> 'ro',
	isa			=> 'Str',
	init_arg	=> undef,
	default		=> qq{«},
);

has 'quote_end' => (
	is			=> 'ro',
	isa			=> 'Str',
	init_arg	=> undef,
	default		=> qq{»},
);

has 'alternate_quote_start' => (
	is			=> 'ro',
	isa			=> 'Str',
	init_arg	=> undef,
	default		=> qq{„},
);

has 'alternate_quote_end' => (
	is			=> 'ro',
	isa			=> 'Str',
	init_arg	=> undef,
	default		=> qq{”},
);

has 'yesstr' => (
	is			=> 'ro',
	isa			=> 'RegexpRef',
	init_arg	=> undef,
	default		=> sub { qr'^(?i:ⵢⵢⵉⵀ|ⵢ|yes|y)$' }
);

has 'nostr' => (
	is			=> 'ro',
	isa			=> 'RegexpRef',
	init_arg	=> undef,
	default		=> sub { qr'^(?i:ⵓⵀⵓ|ⵓ|no|n)$' }
);

has 'number_symbols' => (
	is			=> 'ro',
	isa			=> 'HashRef',
	init_arg	=> undef,
	default		=> sub { {
		'latn' => {
			'decimal' => q(,),
			'exponential' => q(),
			'group' => q( ),
			'infinity' => q(),
			'list' => q(),
			'minusSign' => q(),
			'nan' => q(),
			'perMille' => q(),
			'percentSign' => q(),
			'plusSign' => q(),
			'superscriptingExponent' => q(),
		},
	} }
);

has 'number_formats' => (
	is			=> 'ro',
	isa			=> 'HashRef',
	init_arg	=> undef,
	default		=> sub { {
		percentFormat => {
			'default' => {
				'0' => {
					'default' => '#,##0 %',
				},
			},
		},
} },
);

has 'number_currency_formats' => (
	is			=> 'ro',
	isa			=> 'HashRef',
	init_arg	=> undef,
	default		=> sub { {
		'latn' => {
			'pattern' => {
				'default' => {
					'standard' => {
						'negative' => '#,##0.00¤',
						'positive' => '#,##0.00¤',
					},
				},
			},
		},
} },
);

has 'curriencies' => (
	is			=> 'ro',
	isa			=> 'HashRef',
	init_arg	=> undef,
	default		=> sub { {
		'AED' => {
			display_name => {
				'default' => q(ⴰⴷⵔⵉⵎ ⵏ ⵍⵉⵎⴰⵔⴰⵜ),
			},
		},
		'AOA' => {
			display_name => {
				'default' => q(ⴽⵡⴰⵏⵣⴰ ⵏ ⴰⵏⴳⵓⵍⴰ),
			},
		},
		'AUD' => {
			display_name => {
				'default' => q(ⴰⴷⵓⵍⴰⵔ ⵏ ⵓⵙⵜⵔⴰⵍⵢⴰ),
			},
		},
		'BHD' => {
			display_name => {
				'default' => q(ⴰⴷⵉⵏⴰⵔ ⵏ ⴱⵃⵔⴰⵢⵏ),
			},
		},
		'BIF' => {
			display_name => {
				'default' => q(ⴼⵔⴰⵏⴽ ⵏ ⴱⵓⵔⵓⵏⴷⵉ),
			},
		},
		'BWP' => {
			display_name => {
				'default' => q(ⴰⴱⵓⵍⴰ ⵏ ⴱⵓⵜⵙⵡⴰⵏⴰ),
			},
		},
		'CAD' => {
			display_name => {
				'default' => q(ⴰⴷⵓⵍⴰⵔ ⵏ ⴽⴰⵏⴰⴷⴰ),
			},
		},
		'CDF' => {
			display_name => {
				'default' => q(ⴼⵔⴰⵏⴽ ⵏ ⴽⵓⵏⴳⵓ),
			},
		},
		'CHF' => {
			display_name => {
				'default' => q(ⴰⴼⵔⴰⵏⴽ ⵏ ⵙⵡⵉⵙⵔⴰ),
			},
		},
		'CNY' => {
			display_name => {
				'default' => q(ⴰⵢⴰⵏ ⵏ ⵛⵛⵉⵏⵡⴰ),
			},
		},
		'CVE' => {
			display_name => {
				'default' => q(ⵉⵙⴽⵓⴷⵓ ⵏ ⴽⴰⴱⴱⵉⵔⴷⵉ),
			},
		},
		'DJF' => {
			display_name => {
				'default' => q(ⴼⵔⴰⵏⴽ ⵏ ⴷⵊⵉⴱⵓⵜⵉ),
			},
		},
		'DZD' => {
			display_name => {
				'default' => q(ⴰⴷⵉⵏⴰⵔ ⵏ ⴷⵣⴰⵢⵔ),
			},
		},
		'EGP' => {
			display_name => {
				'default' => q(ⴰⵊⵏⵉⵀ ⵏ ⵎⵉⵚⵕ),
			},
		},
		'ERN' => {
			display_name => {
				'default' => q(ⵏⴰⴼⴽⴰ ⵏ ⵉⵔⵉⵜⵉⵔⵢⴰ),
			},
		},
		'ETB' => {
			display_name => {
				'default' => q(ⴱⵉⵔ ⵏ ⵉⵜⵢⵓⴱⵢⴰ),
			},
		},
		'EUR' => {
			display_name => {
				'default' => q(ⵓⵔⵓ),
			},
		},
		'GBP' => {
			display_name => {
				'default' => q(ⴰⵊⵏⵉⵀ ⴰⵙⵜⵔⵍⵉⵏⵉ ⵏ ⵏⵏⴳⵍⵉⵣ),
			},
		},
		'GHS' => {
			display_name => {
				'default' => q(ⵙⵉⴷⵉ ⵏ ⵖⴰⵏⴰ),
			},
		},
		'GMD' => {
			display_name => {
				'default' => q(ⴷⴰⵍⴰⵙⵉ ⵏ ⴳⴰⵎⴱⵢⴰ),
			},
		},
		'INR' => {
			display_name => {
				'default' => q(ⴰⵔⵓⴱⵉ ⵏ ⵍⵀⵉⵏⴷ),
			},
		},
		'JPY' => {
			display_name => {
				'default' => q(ⴰⵢⴰⵏ ⵏ ⵍⵢⴰⴱⴰⵏ),
			},
		},
		'KES' => {
			display_name => {
				'default' => q(ⴰⵛⵉⵍⵉⵏ ⵏ ⴽⵉⵏⵢⴰ),
			},
		},
		'KMF' => {
			display_name => {
				'default' => q(ⴼⵔⴰⵏⴽ ⵏ ⵇⵓⵎⵓⵕ),
			},
		},
		'LRD' => {
			display_name => {
				'default' => q(ⴰⴷⵓⵍⴰⵔ ⵏ ⵍⵉⴱⵉⵔⵢⴰ),
			},
		},
		'LSL' => {
			display_name => {
				'default' => q(ⵍⵓⵜⵉ ⵏ ⵍⵉⵚⵓⵟⵓ),
			},
		},
		'LYD' => {
			display_name => {
				'default' => q(ⴰⴷⵉⵏⴰⵔ ⵏ ⵍⵉⴱⵢⴰ),
			},
		},
		'MAD' => {
			display_name => {
				'default' => q(ⴰⴷⵔⵉⵎ ⵏ ⵍⵎⵖⵔⵉⴱ),
			},
		},
		'MGA' => {
			display_name => {
				'default' => q(ⴼⵔⴰⵏⴽ ⵏ ⵎⴰⴷⴰⵖⴰⵛⵇⴰⵔ),
			},
		},
		'MRO' => {
			display_name => {
				'default' => q(ⵓⵇⵉⵢⵢⴰ ⵏ ⵎⵓⵕⵉⵟⴰⵏⵢⴰ),
			},
		},
		'MUR' => {
			display_name => {
				'default' => q(ⴰⵔⵓⴱⵉ ⵏ ⵎⵓⵔⵉⵙ),
			},
		},
		'MWK' => {
			display_name => {
				'default' => q(ⴽⵡⴰⵛⴰ ⵏ ⵎⴰⵍⴰⵡⵉ),
			},
		},
		'MZN' => {
			display_name => {
				'default' => q(ⴰⵎⵉⵜⵉⴽⵍ ⵏ ⵎⵓⵣⵏⴱⵉⵇ),
			},
		},
		'NAD' => {
			display_name => {
				'default' => q(ⴰⴷⵓⵍⴰⵔ ⵏ ⵏⴰⵎⵉⴱⵢⴰ),
			},
		},
		'NGN' => {
			display_name => {
				'default' => q(ⵏⴰⵢⵔⴰ ⵏ ⵏⵉⵊⵉⵔⵢⴰ),
			},
		},
		'RWF' => {
			display_name => {
				'default' => q(ⴰⴼⵔⴰⵏⴽ ⵏ ⵔⵡⴰⵏⴷⴰ),
			},
		},
		'SAR' => {
			display_name => {
				'default' => q(ⴰⵔⵢⴰⵍ ⵏ ⵙⵙⴰⵄⵓⴷⵉⵢⴰ),
			},
		},
		'SCR' => {
			display_name => {
				'default' => q(ⴰⵔⵓⴱⵉ ⵏ ⵙⵙⵉⵛⵉⵍ),
			},
		},
		'SDG' => {
			display_name => {
				'default' => q(ⴰⴷⵉⵏⴰⵔ ⵏ ⵙⵙⵓⴷⴰⵏ),
			},
		},
		'SDP' => {
			display_name => {
				'default' => q(ⴰⵊⵏⵉⵀ ⵏ ⵙⵙⵓⴷⴰⵏ),
			},
		},
		'SHP' => {
			display_name => {
				'default' => q(ⴰⵊⵏⵉⵀ ⵏ ⵙⴰⵏⵜⵉⵍⵉⵏ),
			},
		},
		'SLL' => {
			display_name => {
				'default' => q(ⵍⵉⵢⵓⵏ),
			},
		},
		'SOS' => {
			display_name => {
				'default' => q(ⴰⵛⵉⵍⵉⵏ ⵏ ⵚⵚⵓⵎⴰⵍ),
			},
		},
		'STD' => {
			display_name => {
				'default' => q(ⴰⴷⵓⴱⵔⴰ ⵏ ⵙⴰⵏⵟⵓⵎⵉ),
			},
		},
		'SZL' => {
			display_name => {
				'default' => q(ⵍⵉⵍⴰⵏⵊⵉⵏⵉ),
			},
		},
		'TND' => {
			display_name => {
				'default' => q(ⴰⴷⵉⵏⴰⵔ ⵏ ⵜⵓⵏⵙ),
			},
		},
		'TZS' => {
			display_name => {
				'default' => q(ⴰⵛⵉⵍⵉⵏ ⵏ ⵟⴰⵏⵥⴰⵏⵢⴰ),
			},
		},
		'UGX' => {
			display_name => {
				'default' => q(ⴰⵛⵉⵍⵉⵏ ⵏ ⵓⵖⴰⵏⴷⴰ),
			},
		},
		'USD' => {
			display_name => {
				'default' => q(ⴰⴷⵓⵍⴰⵔ ⵏ ⵉⵡⵓⵏⴰⴽ ⵉⵎⵓⵏⵏ),
			},
		},
		'XAF' => {
			display_name => {
				'default' => q(ⴼⵔⴰⵏⴽ ⵚⵉⴼⴰ),
			},
		},
		'XOF' => {
			display_name => {
				'default' => q(ⴼⵔⴰⵏⴽ ⵚⵉⴼⴰ ⴱⵉⵙⴰⵡ),
			},
		},
		'ZAR' => {
			display_name => {
				'default' => q(ⴰⵔⴰⵏⴷ ⵏ ⴰⴼⵔⵉⵇⵢⴰ ⵏ ⵉⴼⴼⵓⵙ),
			},
		},
		'ZMK' => {
			display_name => {
				'default' => q(ⴰⴽⵡⴰⵛⴰ ⵏ ⵣⴰⵎⴱⵢⴰ (1968–2012)),
			},
		},
		'ZMW' => {
			display_name => {
				'default' => q(ⴰⴽⵡⴰⵛⴰ ⵏ ⵣⴰⵎⴱⵢⴰ),
			},
		},
		'ZWD' => {
			display_name => {
				'default' => q(ⴰⴷⵓⵍⴰⵔ ⵏ ⵣⵉⵎⴱⴰⴱⵡⵉ (1980–2008)),
			},
		},
		'ZWL' => {
			display_name => {
				'default' => q(ⴰⴷⵓⵍⴰⵔ ⵏ ⵣⵉⵎⴱⴰⴱⵡⵉ (2009)),
			},
		},
		'ZWR' => {
			display_name => {
				'default' => q(ⴰⴷⵓⵍⴰⵔ ⵏ ⵣⵉⵎⴱⴰⴱⵡⵉ (2008)),
			},
		},
	} },
);


has 'calendar_months' => (
	is			=> 'ro',
	isa			=> 'HashRef',
	init_arg	=> undef,
	default		=> sub { {
			'gregorian' => {
				'format' => {
					abbreviated => {
						nonleap => [
							'ⵉⵏⵏ',
							'ⴱⵕⴰ',
							'ⵎⴰⵕ',
							'ⵉⴱⵔ',
							'ⵎⴰⵢ',
							'ⵢⵓⵏ',
							'ⵢⵓⵍ',
							'ⵖⵓⵛ',
							'ⵛⵓⵜ',
							'ⴽⵜⵓ',
							'ⵏⵓⵡ',
							'ⴷⵓⵊ'
						],
						leap => [
							
						],
					},
					wide => {
						nonleap => [
							'ⵉⵏⵏⴰⵢⵔ',
							'ⴱⵕⴰⵢⵕ',
							'ⵎⴰⵕⵚ',
							'ⵉⴱⵔⵉⵔ',
							'ⵎⴰⵢⵢⵓ',
							'ⵢⵓⵏⵢⵓ',
							'ⵢⵓⵍⵢⵓⵣ',
							'ⵖⵓⵛⵜ',
							'ⵛⵓⵜⴰⵏⴱⵉⵔ',
							'ⴽⵜⵓⴱⵔ',
							'ⵏⵓⵡⴰⵏⴱⵉⵔ',
							'ⴷⵓⵊⴰⵏⴱⵉⵔ'
						],
						leap => [
							
						],
					},
				},
				'stand-alone' => {
					narrow => {
						nonleap => [
							'ⵉ',
							'ⴱ',
							'ⵎ',
							'ⵉ',
							'ⵎ',
							'ⵢ',
							'ⵢ',
							'ⵖ',
							'ⵛ',
							'ⴽ',
							'ⵏ',
							'ⴷ'
						],
						leap => [
							
						],
					},
				},
			},
	} },
);

has 'calendar_days' => (
	is			=> 'ro',
	isa			=> 'HashRef',
	init_arg	=> undef,
	default		=> sub { {
			'gregorian' => {
				'format' => {
					abbreviated => {
						mon => 'ⴰⵢⵏ',
						tue => 'ⴰⵙⵉ',
						wed => 'ⴰⴽⵕ',
						thu => 'ⴰⴽⵡ',
						fri => 'ⴰⵙⵉⵎ',
						sat => 'ⴰⵙⵉⴹ',
						sun => 'ⴰⵙⴰ'
					},
					wide => {
						mon => 'ⴰⵢⵏⴰⵙ',
						tue => 'ⴰⵙⵉⵏⴰⵙ',
						wed => 'ⴰⴽⵕⴰⵙ',
						thu => 'ⴰⴽⵡⴰⵙ',
						fri => 'ⴰⵙⵉⵎⵡⴰⵙ',
						sat => 'ⴰⵙⵉⴹⵢⴰⵙ',
						sun => 'ⴰⵙⴰⵎⴰⵙ'
					},
				},
			},
	} },
);

has 'calendar_quarters' => (
	is			=> 'ro',
	isa			=> 'HashRef',
	init_arg	=> undef,
	default		=> sub { {
			'gregorian' => {
				'format' => {
					abbreviated => {0 => 'ⴰⴽ 1',
						1 => 'ⴰⴽ 2',
						2 => 'ⴰⴽ 3',
						3 => 'ⴰⴽ 4'
					},
					wide => {0 => 'ⴰⴽⵕⴰⴹⵢⵓⵔ 1',
						1 => 'ⴰⴽⵕⴰⴹⵢⵓⵔ 2',
						2 => 'ⴰⴽⵕⴰⴹⵢⵓⵔ 3',
						3 => 'ⴰⴽⵕⴰⴹⵢⵓⵔ 4'
					},
				},
			},
	} },
);

has 'day_periods' => (
	is			=> 'ro',
	isa			=> 'HashRef',
	init_arg	=> undef,
	default		=> sub { {
		'gregorian' => {
			'format' => {
				'wide' => {
					'pm' => q{ⵜⴰⴷⴳⴳⵯⴰⵜ},
					'am' => q{ⵜⵉⴼⴰⵡⵜ},
				},
			},
		},
	} },
);

has 'eras' => (
	is			=> 'ro',
	isa			=> 'HashRef',
	init_arg	=> undef,
	default		=> sub { {
		'generic' => {
		},
		'gregorian' => {
			abbreviated => {
				'0' => 'ⴷⴰⵄ',
				'1' => 'ⴷⴼⵄ'
			},
			wide => {
				'0' => 'ⴷⴰⵜ ⵏ ⵄⵉⵙⴰ',
				'1' => 'ⴷⴼⴼⵉⵔ ⵏ ⵄⵉⵙⴰ'
			},
		},
	} },
);

has 'date_formats' => (
	is			=> 'ro',
	isa			=> 'HashRef',
	init_arg	=> undef,
	default		=> sub { {
		'generic' => {
			'full' => q{EEEE d MMMM y G},
			'long' => q{d MMMM y G},
			'medium' => q{d MMM, y G},
			'short' => q{d/M/y GGGGG},
		},
		'gregorian' => {
			'full' => q{EEEE d MMMM y},
			'long' => q{d MMMM y},
			'medium' => q{d MMM, y},
			'short' => q{d/M/y},
		},
	} },
);

has 'time_formats' => (
	is			=> 'ro',
	isa			=> 'HashRef',
	init_arg	=> undef,
	default		=> sub { {
		'generic' => {
		},
		'gregorian' => {
			'full' => q{HH:mm:ss zzzz},
			'long' => q{HH:mm:ss z},
			'medium' => q{HH:mm:ss},
			'short' => q{HH:mm},
		},
	} },
);

has 'datetime_formats' => (
	is			=> 'ro',
	isa			=> 'HashRef',
	init_arg	=> undef,
	default		=> sub { {
		'generic' => {
		},
		'gregorian' => {
		},
	} },
);

has 'datetime_formats_available_formats' => (
	is			=> 'ro',
	isa			=> 'HashRef',
	init_arg	=> undef,
	default		=> sub { {
		'generic' => {
			M => q{M},
			MMM => q{MMM},
			MMMEd => q{E d MMM},
			MMMd => q{d MMM},
			Md => q{d/M},
			y => q{y},
		},
		'gregorian' => {
			M => q{M},
			MMM => q{MMM},
			MMMEd => q{E d MMM},
			MMMd => q{d MMM},
			Md => q{d/M},
			ms => q{m:ss},
			y => q{y},
			yM => q{M/y},
			yMEd => q{E d/M/y},
			yMMM => q{MMM y},
			yMMMEd => q{E d MMM y},
			yQQQ => q{QQQ y},
			yQQQQ => q{QQQQ y},
		},
	} },
);

has 'datetime_formats_append_item' => (
	is			=> 'ro',
	isa			=> 'HashRef',
	init_arg	=> undef,
	default		=> sub { {
	} },
);

has 'datetime_formats_interval' => (
	is			=> 'ro',
	isa			=> 'HashRef',
	init_arg	=> undef,
	default		=> sub { {
	} },
);

