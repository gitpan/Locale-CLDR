package Locale::CLDR::Eu::Any::Es;
# This file auto generated from Data\common\main\eu_ES.xml
#	on Mon 31 Mar 12:18:19 am GMT
# XML file generated 2013-07-20 12:27:45 -0500 (Sat, 20 Jul 2013)

use v5.18;
use mro 'c3';
use utf8;

use Moose;

extends('Locale::CLDR::Eu::Any');
