package Locale::CLDR::Bg::Any;
# This file auto generated
#	on Sun 23 Mar  7:18:25 pm GMT

use v5.18;
use mro 'c3';

use Moose;

extends('Locale::CLDR::Bg');

no Moose;
__PACKAGE__->meta->make_immutable;
