package Locale::CLDR::Dav::Any;
# This file auto generated
#	on Sun 23 Mar  7:27:03 pm GMT

use v5.18;
use mro 'c3';

use Moose;

extends('Locale::CLDR::Dav');

no Moose;
__PACKAGE__->meta->make_immutable;
