package Locale::CLDR::En::Any::Bw;
# This file auto generated from Data\common\main\en_BW.xml
#	on Mon 31 Mar 12:12:14 am GMT
# XML file generated 2014-01-08 23:53:23 -0600 (Wed, 08 Jan 2014)

use v5.18;
use mro 'c3';
use utf8;

use Moose;

extends('Locale::CLDR::En::Any');
