package Locale::CLDR::Fr::Any;
# This file auto generated
#	on Sun 23 Mar  7:38:57 pm GMT

use v5.18;
use mro 'c3';

use Moose;

extends('Locale::CLDR::Fr');

no Moose;
__PACKAGE__->meta->make_immutable;
