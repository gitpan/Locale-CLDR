package Locale::CLDR::Ca::Any::Es::Valencia;
# This file auto generated from Data\common\main\ca_ES_VALENCIA.xml
#	on Sun 30 Mar 11:58:45 pm GMT
# XML file generated 2014-02-27 11:17:08 -0600 (Thu, 27 Feb 2014)

use v5.18;
use mro 'c3';
use utf8;

use Moose;

extends('Locale::CLDR::Ca::Any::Es');
