package Locale::CLDR::Fil::Any;
# This file auto generated
#	on Sun 23 Mar  7:38:11 pm GMT

use v5.18;
use mro 'c3';

use Moose;

extends('Locale::CLDR::Fil');

no Moose;
__PACKAGE__->meta->make_immutable;
