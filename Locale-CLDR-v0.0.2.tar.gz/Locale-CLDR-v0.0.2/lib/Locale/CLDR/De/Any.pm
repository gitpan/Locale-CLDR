package Locale::CLDR::De::Any;
# This file auto generated
#	on Sun 23 Mar  7:27:38 pm GMT

use v5.18;
use mro 'c3';

use Moose;

extends('Locale::CLDR::De');

no Moose;
__PACKAGE__->meta->make_immutable;
