package Locale::CLDR::Ast::Any;
# This file auto generated
#	on Sun 23 Mar  7:15:27 pm GMT

use v5.18;
use mro 'c3';

use Moose;

extends('Locale::CLDR::Ast');

no Moose;
__PACKAGE__->meta->make_immutable;
