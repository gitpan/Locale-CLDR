package Locale::CLDR::Fo::Any;
# This file auto generated
#	on Sun 23 Mar  7:38:13 pm GMT

use v5.18;
use mro 'c3';

use Moose;

extends('Locale::CLDR::Fo');

no Moose;
__PACKAGE__->meta->make_immutable;
