package Locale::CLDR::Fo::Any::Fo;
# This file auto generated from Data\common\main\fo_FO.xml
#	on Mon 31 Mar 12:23:28 am GMT
# XML file generated 2013-07-20 12:27:45 -0500 (Sat, 20 Jul 2013)

use v5.18;
use mro 'c3';
use utf8;

use Moose;

extends('Locale::CLDR::Fo::Any');
