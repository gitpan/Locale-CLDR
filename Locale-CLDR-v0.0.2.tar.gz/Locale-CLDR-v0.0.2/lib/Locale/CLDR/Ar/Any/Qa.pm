package Locale::CLDR::Ar::Any::Qa;
# This file auto generated from Data\common\main\ar_QA.xml
#	on Sun 30 Mar 11:40:20 pm GMT
# XML file generated 2013-08-28 21:32:04 -0500 (Wed, 28 Aug 2013)

use v5.18;
use mro 'c3';
use utf8;

use Moose;

extends('Locale::CLDR::Ar::Any');
