package Locale::CLDR::Ar::Any;
# This file auto generated
#	on Sun 23 Mar  7:15:18 pm GMT

use v5.18;
use mro 'c3';

use Moose;

extends('Locale::CLDR::Ar');

no Moose;
__PACKAGE__->meta->make_immutable;
