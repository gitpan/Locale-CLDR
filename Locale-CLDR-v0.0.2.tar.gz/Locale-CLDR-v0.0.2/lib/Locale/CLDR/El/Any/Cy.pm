package Locale::CLDR::El::Any::Cy;
# This file auto generated from Data\common\main\el_CY.xml
#	on Mon 31 Mar 12:10:33 am GMT
# XML file generated 2013-08-28 21:32:04 -0500 (Wed, 28 Aug 2013)

use v5.18;
use mro 'c3';
use utf8;

use Moose;

extends('Locale::CLDR::El::Any');
