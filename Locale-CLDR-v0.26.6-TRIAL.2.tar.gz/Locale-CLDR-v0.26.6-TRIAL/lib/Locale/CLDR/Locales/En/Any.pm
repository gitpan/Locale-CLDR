package Locale::CLDR::Locales::En::Any;

# This file auto generated
#	on Sun 28 Dec  8:43:59 am GMT

use version;

our $VERSION = version->declare('v0.26.6');

use v5.10;
use mro 'c3';
use if $^V ge v5.12.0, feature => 'unicode_strings';

use Moose;

extends('Locale::CLDR::Locales::En');

no Moose;
__PACKAGE__->meta->make_immutable;
